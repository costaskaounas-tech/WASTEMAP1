# No project-specific rules are required for the native WebView shell.
